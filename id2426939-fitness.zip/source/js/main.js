import './form.js';
import './video.js';
import './tab.js';
import './question-tab.js';
import './reviews-slider.js';
import './jury-slider.js';
